<?php

include_once CUTHBERT_CORE_INC_PATH . '/side-area/widgets/side-area-opener/class-cuthbertcore-side-area-opener-widget.php';
