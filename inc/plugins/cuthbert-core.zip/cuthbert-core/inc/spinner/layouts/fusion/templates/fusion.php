<div class="qodef-m-fusion">
	<div class="qodef-m-fusion-item qodef-fusion--1"></div>
	<div class="qodef-m-fusion-item qodef-fusion--2"></div>
	<div class="qodef-m-fusion-item qodef-fusion--3"></div>
	<div class="qodef-m-fusion-item qodef-fusion--4"></div>
</div>
