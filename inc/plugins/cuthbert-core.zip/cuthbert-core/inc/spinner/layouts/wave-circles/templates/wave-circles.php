<div class="qodef-m-wave-circles">
	<div class="qodef-m-wave-circle qodef-wave--1"></div>
	<div class="qodef-m-wave-circle qodef-wave--2"></div>
	<div class="qodef-m-wave-circle qodef-wave--3"></div>
	<div class="qodef-m-wave-circle qodef-wave--4"></div>
</div>
