<div class="qodef-m-atom">
	<div class="qodef-m-atom-item qodef-atom--1"></div>
	<div class="qodef-m-atom-item qodef-atom--2"></div>
	<div class="qodef-m-atom-item qodef-atom--3"></div>
	<div class="qodef-m-atom-item qodef-atom--4"></div>
</div>
