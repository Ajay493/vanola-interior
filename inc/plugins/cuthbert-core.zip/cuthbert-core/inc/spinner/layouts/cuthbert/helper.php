<?php

if ( ! function_exists( 'cuthbert_core_add_cuthbert_spinner_layout_option' ) ) {
	/**
	 * Function that set new value into page spinner layout options map
	 *
	 * @param array $layouts - module layouts
	 *
	 * @return array
	 */
	function cuthbert_core_add_cuthbert_spinner_layout_option( $layouts ) {
		$layouts['cuthbert'] = esc_html__( 'Cuthbert', 'cuthbert-core' );

		return $layouts;
	}

	add_filter( 'cuthbert_core_filter_page_spinner_layout_options', 'cuthbert_core_add_cuthbert_spinner_layout_option' );
}

if ( ! function_exists( 'cuthbert_core_set_cuthbert_spinner_layout_as_default_option' ) ) {
	/**
	 * Function that set default value for page spinner layout options map
	 *
	 * @param string $default_value
	 *
	 * @return string
	 */
	function cuthbert_core_set_cuthbert_spinner_layout_as_default_option( $default_value ) {
		return 'cuthbert';
	}

	add_filter( 'cuthbert_core_filter_page_spinner_default_layout_option', 'cuthbert_core_set_cuthbert_spinner_layout_as_default_option' );
}
