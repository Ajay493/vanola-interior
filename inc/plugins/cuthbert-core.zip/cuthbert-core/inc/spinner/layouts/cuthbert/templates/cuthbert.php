<?php
$spinner_gallery = cuthbert_core_get_post_value_through_levels( 'qodef_page_spinner_gallery' );
$image_ids       = explode( ',', $spinner_gallery );

if ( ! empty( $image_ids ) ) {
	foreach ( $image_ids as $image ) {
		echo '<div class="qodef-m-cuthbert-image">';
		echo wp_get_attachment_image( $image, 'full' );
		echo '</div>';
	}
}