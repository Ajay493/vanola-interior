<div class="qodef-m-wave">
	<div class="qodef-m-wave-item qodef-wave--1"></div>
	<div class="qodef-m-wave-item qodef-wave--2"></div>
	<div class="qodef-m-wave-item qodef-wave--3"></div>
</div>
