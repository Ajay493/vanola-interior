<?php

include_once CUTHBERT_CORE_INC_PATH . '/spinner/layouts/stripes/helper.php';
