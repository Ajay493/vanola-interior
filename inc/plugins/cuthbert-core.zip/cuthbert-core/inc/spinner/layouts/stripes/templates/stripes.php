<div class="qodef-m-stripes">
	<div class="qodef-m-stripe qodef-stripe--1"></div>
	<div class="qodef-m-stripe qodef-stripe--2"></div>
	<div class="qodef-m-stripe qodef-stripe--3"></div>
	<div class="qodef-m-stripe qodef-stripe--4"></div>
	<div class="qodef-m-stripe qodef-stripe--5"></div>
</div>
