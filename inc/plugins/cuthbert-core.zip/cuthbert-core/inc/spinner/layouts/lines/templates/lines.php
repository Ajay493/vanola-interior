<div class="qodef-m-lines">
	<div class="qodef-m-line qodef-line--1"></div>
	<div class="qodef-m-line qodef-line--2"></div>
	<div class="qodef-m-line qodef-line--3"></div>
	<div class="qodef-m-line qodef-line--4"></div>
</div>
