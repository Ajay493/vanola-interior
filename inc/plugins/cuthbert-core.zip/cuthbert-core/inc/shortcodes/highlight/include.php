<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/highlight/class-cuthbertcore-highlight-shortcode.php';
