<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/countdown/variations/simple/helper.php';
