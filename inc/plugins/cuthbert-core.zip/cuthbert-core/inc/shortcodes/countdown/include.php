<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/countdown/class-cuthbertcore-countdown-shortcode.php';

foreach ( glob( CUTHBERT_CORE_SHORTCODES_PATH . '/countdown/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
