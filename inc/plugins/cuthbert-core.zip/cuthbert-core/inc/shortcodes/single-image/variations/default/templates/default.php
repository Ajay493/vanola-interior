<div <?php qode_framework_class_attribute( $holder_classes ); ?> <?php qode_framework_inline_style( $holder_styles ); ?>>
	<?php cuthbert_core_template_part( 'shortcodes/single-image', 'templates/parts/image', '', $params ); ?>
</div>
