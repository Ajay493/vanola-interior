<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/single-image/class-cuthbertcore-single-image-shortcode.php';

foreach ( glob( CUTHBERT_CORE_SHORTCODES_PATH . '/single-image/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
