<?php

if ( ! function_exists( 'cuthbert_core_add_single_image_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param $shortcodes array
	 *
	 * @return array
	 */
	function cuthbert_core_add_single_image_shortcode( $shortcodes ) {
		$shortcodes[] = 'CuthbertCore_Single_Image_Shortcode';

		return $shortcodes;
	}

	add_filter( 'cuthbert_core_filter_register_shortcodes', 'cuthbert_core_add_single_image_shortcode' );
}

if ( class_exists( 'CuthbertCore_Shortcode' ) ) {
	class CuthbertCore_Single_Image_Shortcode extends CuthbertCore_Shortcode {

		public function __construct() {
			$this->set_layouts( apply_filters( 'cuthbert_core_filter_single_image_layouts', array() ) );
			$this->set_extra_options( apply_filters( 'cuthbert_core_filter_single_image_extra_options', array() ) );

			parent::__construct();
		}

		public function map_shortcode() {
			$this->set_shortcode_path( CUTHBERT_CORE_SHORTCODES_URL_PATH . '/single-image' );
			$this->set_base( 'cuthbert_core_single_image' );
			$this->set_name( esc_html__( 'Single Image', 'cuthbert-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds image element', 'cuthbert-core' ) );
			$this->set_scripts(
				array(
					'jquery-magnific-popup' => array(
						'registered' => true,
					),
				)
			);
			$this->set_necessary_styles(
				array(
					'magnific-popup' => array(
						'registered' => true,
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'custom_class',
					'title'      => esc_html__( 'Custom Class', 'cuthbert-core' ),
				)
			);

			$options_map = cuthbert_core_get_variations_options_map( $this->get_layouts() );

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'layout',
					'title'         => esc_html__( 'Layout', 'cuthbert-core' ),
					'options'       => $this->get_layouts(),
					'default_value' => $options_map['default_value'],
					'visibility'    => array( 'map_for_page_builder' => $options_map['visibility'] ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'image',
					'name'       => 'image',
					'title'      => esc_html__( 'Image', 'cuthbert-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'height',
					'title'      => esc_html__( 'Height', 'cuthbert-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'retina_scaling',
					'title'         => esc_html__( 'Enable Retina Scaling', 'cuthbert-core' ),
					'description'   => esc_html__( 'Image uploaded should be two times the height.', 'cuthbert-core' ),
					'options'       => cuthbert_core_get_select_type_options_pool( 'yes_no' ),
					'default_value' => '',
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'images_proportion',
					'default_value' => 'full',
					'title'         => esc_html__( 'Image Proportions', 'cuthbert-core' ),
					'options'       => cuthbert_core_get_select_type_options_pool( 'list_image_dimension', false ),
					'dependency'    => array(
						'hide' => array(
							'retina_scaling' => array(
								'values'        => 'yes',
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'text',
					'name'        => 'custom_image_width',
					'title'       => esc_html__( 'Custom Image Width', 'cuthbert-core' ),
					'description' => esc_html__( 'Enter image width in px', 'cuthbert-core' ),
					'dependency'  => array(
						'show' => array(
							'images_proportion' => array(
								'values'        => 'custom',
								'default_value' => 'full',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'  => 'text',
					'name'        => 'custom_image_height',
					'title'       => esc_html__( 'Custom Image Height', 'cuthbert-core' ),
					'description' => esc_html__( 'Enter image height in px', 'cuthbert-core' ),
					'dependency'  => array(
						'show' => array(
							'images_proportion' => array(
								'values'        => 'custom',
								'default_value' => 'full',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'image_action',
					'title'      => esc_html__( 'Image Action', 'cuthbert-core' ),
					'options'    => array(
						''            => esc_html__( 'No Action', 'cuthbert-core' ),
						'open-popup'  => esc_html__( 'Open Popup', 'cuthbert-core' ),
						'custom-link' => esc_html__( 'Custom Link', 'cuthbert-core' ),
					),
				)
			);
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'link',
					'title'      => esc_html__( 'Custom Link', 'cuthbert-core' ),
					'dependency' => array(
						'show' => array(
							'image_action' => array(
								'values'        => array( 'custom-link' ),
								'default_value' => '',
							),
						),
					),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'target',
					'title'         => esc_html__( 'Custom Link Target', 'cuthbert-core' ),
					'options'       => cuthbert_core_get_select_type_options_pool( 'link_target' ),
					'default_value' => '_self',
					'dependency'    => array(
						'show' => array(
							'image_action' => array(
								'values'        => 'custom-link',
								'default_value' => '',
							),
						),
					),
				)
			);

			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'parallax_item',
					'title'         => esc_html__( 'Enable Parallax Item', 'cuthbert-core' ),
					'options'       => cuthbert_core_get_select_type_options_pool( 'yes_no' ),
					'default_value' => '',
				)
			);

			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'custom_parallax',
					'title'      => esc_html__( 'Custom Parallax Effect', 'cuthbert-core' ),
					'options'    => cuthbert_core_get_select_type_options_pool( 'no_yes', false ),
				)
			);

			$this->set_option(
				array(
					'field_type' => 'select',
					'name'       => 'appear',
					'title'      => esc_html__( 'Appear Animation', 'cuthbert-core' ),
					'options'    => cuthbert_core_get_select_type_options_pool( 'no_yes', false ),
				)
			);

			$this->map_extra_options();
		}

		public static function call_shortcode( $params ) {
			$html = qode_framework_call_shortcode( 'cuthbert_core_single_image', $params );
			$html = str_replace( "\n", '', $html );

			return $html;
		}

		public function load_assets() {

			if ( isset( $atts['image_action'] ) && 'open-popup' === $atts['image_action'] ) {
				wp_enqueue_style( 'magnific-popup' );
				wp_enqueue_script( 'jquery-magnific-popup' );
			}
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts = $this->get_atts();

			$atts['holder_classes'] = $this->get_holder_classes( $atts );
			$atts['holder_styles']  = $this->get_holder_styles( $atts );

			return cuthbert_core_get_template_part( 'shortcodes/single-image', 'variations/' . $atts['layout'] . '/templates/' . $atts['layout'], '', $atts );
		}

		private function get_holder_classes( $atts ) {
			$holder_classes = $this->init_holder_classes();

			$holder_classes[] = 'qodef-single-image';
			$holder_classes[] = ! empty( $atts['layout'] ) ? 'qodef-layout--' . $atts['layout'] : '';
			$holder_classes[] = ! empty( $atts['parallax_item'] ) && ( 'yes' === $atts['parallax_item'] ) ? 'qodef-parallax-item' : '';
			$holder_classes[] = ( 'yes' === $atts['retina_scaling'] ) ? 'qodef--retina' : '';
			$holder_classes[] = ! empty( $atts['height'] ) ? 'qodef--force-height' : '';
			$holder_classes[] = ! empty( $atts['custom_parallax'] ) && ( 'yes' === $atts['custom_parallax'] ) ? 'qodef-custom-parallax' : '';
			$holder_classes[] = ! empty( $atts['appear'] ) && ( 'yes' === $atts['appear'] ) ? 'qodef-has-appear' : '';

			return implode( ' ', $holder_classes );
		}

		private function get_holder_styles( $atts ) {
			$styles = array();

			$height = $atts['height'];
			if ( ! empty( $height ) ) {
				// if ( qode_framework_string_ends_with_space_units( $height, true ) ) {
				$styles[] = 'height: ' . $height;
				// } else {
				// 	$styles[] = 'height: ' . intval( $height ) . 'px';
				// }
			}

			return implode( ';', $styles );
		}
	}
}
