<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/single-image/widget/class-cuthbertcore-single-image-widget.php';
