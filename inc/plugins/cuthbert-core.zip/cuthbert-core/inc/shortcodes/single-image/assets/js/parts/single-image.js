(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.cuthbert_core_image_with_text = {};

	$( document ).ready(
		function () {
			qodefSingleImage.init();
		}
	);

	var qodefSingleImage = {
		init: function () {
			this.holder = $( '.qodef-single-image' );

			if ( this.holder.length ) {
				this.holder.each(
					function () {
						qodefSingleImage.initItem( $( this ) );
					}
				);
			}
		},
		initItem: function ( $currentItem ) {
			if ( $currentItem.hasClass( 'qodef-has-appear' ) ) {
				qodef.qodefWaitForImages.check(
					$currentItem,
					function () {
						qodefCore.qodefIsInViewport.check(
							$currentItem,
							function () {
								$currentItem.addClass( 'qodef--appeared' );
							}
						);
					}
				);
			}
		},
	};

	qodefCore.shortcodes.cuthbert_core_image_with_text.qodefSingleImage = qodefSingleImage;

})( jQuery );
