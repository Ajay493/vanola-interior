<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/button/class-cuthbertcore-button-shortcode.php';

foreach ( glob( CUTHBERT_CORE_SHORTCODES_PATH . '/button/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
