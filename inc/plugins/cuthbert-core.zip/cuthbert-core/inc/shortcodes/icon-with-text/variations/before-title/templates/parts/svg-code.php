<?php if ( 'svg-code' === $icon_type && ! empty( $svg_code ) ) { ?>
	<?php echo qode_framework_wp_kses_html( 'svg', $svg_code ); ?>
	<?php
}
