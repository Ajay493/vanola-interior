<?php

if ( 'icon-pack' === $icon_type ) {
	echo CuthbertCore_Icon_Shortcode::call_shortcode( $icon_params );
}
