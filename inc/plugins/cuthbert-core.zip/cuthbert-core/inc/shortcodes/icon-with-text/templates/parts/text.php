<?php if ( ! empty( $text ) ) { ?>
	<p class="qodef-m-text" <?php qode_framework_inline_style( $text_styles ); ?>><?php echo esc_html( $text ); ?></p>
<?php } ?>
