<?php

class CuthbertCore_Separator_Shortcode_Elementor extends CuthbertCore_Elementor_Widget_Base {

	public function __construct( array $data = [], $args = null ) {
		$this->set_shortcode_slug( 'cuthbert_core_separator' );

		parent::__construct( $data, $args );
	}
}

cuthbert_core_register_new_elementor_widget( new CuthbertCore_Separator_Shortcode_Elementor() );
