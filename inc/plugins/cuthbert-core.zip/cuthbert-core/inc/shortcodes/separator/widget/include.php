<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/separator/widget/class-cuthbertcore-separator-widget.php';
