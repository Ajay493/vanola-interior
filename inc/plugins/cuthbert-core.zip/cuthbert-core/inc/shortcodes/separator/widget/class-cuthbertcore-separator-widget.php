<?php

if ( ! function_exists( 'cuthbert_core_add_separator_widget' ) ) {
	/**
	 * Function that add widget into widgets list for registration
	 *
	 * @param array $widgets
	 *
	 * @return array
	 */
	function cuthbert_core_add_separator_widget( $widgets ) {
		$widgets[] = 'CuthbertCore_Separator_Widget';

		return $widgets;
	}

	add_filter( 'cuthbert_core_filter_register_widgets', 'cuthbert_core_add_separator_widget' );
}

if ( class_exists( 'QodeFrameworkWidget' ) ) {
	class CuthbertCore_Separator_Widget extends QodeFrameworkWidget {

		public function map_widget() {
			$widget_mapped = $this->import_shortcode_options(
				array(
					'shortcode_base' => 'cuthbert_core_separator',
				)
			);

			if ( $widget_mapped ) {
				$this->set_base( 'cuthbert_core_separator' );
				$this->set_name( esc_html__( 'Cuthbert Separator', 'cuthbert-core' ) );
				$this->set_description( esc_html__( 'Add a separator element into widget areas', 'cuthbert-core' ) );
			}
		}

		public function render( $atts ) {
			echo CuthbertCore_Separator_Shortcode::call_shortcode( $atts ); // XSS OK
		}
	}
}
