<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/separator/class-cuthbertcore-separator-shortcode.php';
