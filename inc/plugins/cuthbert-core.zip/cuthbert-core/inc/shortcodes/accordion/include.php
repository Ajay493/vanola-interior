<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/accordion/class-cuthbertcore-accordion-shortcode.php';
include_once CUTHBERT_CORE_SHORTCODES_PATH . '/accordion/class-cuthbertcore-accordion-child-shortcode.php';

foreach ( glob( CUTHBERT_CORE_SHORTCODES_PATH . '/accordion/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
