<?php

if ( ! function_exists( 'cuthbert_core_add_accordion_child_shortcode' ) ) {
	/**
	 * Function that add shortcode into shortcodes list for registration
	 *
	 * @param array $shortcodes
	 *
	 * @return array
	 */
	function cuthbert_core_add_accordion_child_shortcode( $shortcodes ) {
		$shortcodes[] = 'CuthbertCore_Accordion_Child_Shortcode';

		return $shortcodes;
	}

	add_filter( 'cuthbert_core_filter_register_shortcodes', 'cuthbert_core_add_accordion_child_shortcode' );
}

if ( class_exists( 'CuthbertCore_Shortcode' ) ) {
	class CuthbertCore_Accordion_Child_Shortcode extends CuthbertCore_Shortcode {

		public function map_shortcode() {
			$this->set_shortcode_path( CUTHBERT_CORE_SHORTCODES_URL_PATH . '/accordion' );
			$this->set_base( 'cuthbert_core_accordion_child' );
			$this->set_name( esc_html__( 'Accordion Child', 'cuthbert-core' ) );
			$this->set_description( esc_html__( 'Shortcode that adds accordion child to accordion holder', 'cuthbert-core' ) );
			$this->set_is_child_shortcode( true );
			$this->set_parent_elements(
				array(
					'cuthbert_core_accordion',
				)
			);
			$this->set_is_parent_shortcode( true );
			$this->set_option(
				array(
					'field_type' => 'text',
					'name'       => 'title',
					'title'      => esc_html__( 'Title', 'cuthbert-core' ),
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'select',
					'name'          => 'title_tag',
					'title'         => esc_html__( 'Title Tag', 'cuthbert-core' ),
					'options'       => cuthbert_core_get_select_type_options_pool( 'title_tag', true, array(), array( 'span' => esc_attr__( 'Predefined', 'cuthbert-core' ) ) ),
					'default_value' => 'span',
				)
			);
			$this->set_option(
				array(
					'field_type'    => 'text',
					'name'          => 'layout',
					'title'         => esc_html__( 'Layout', 'cuthbert-core' ),
					'default_value' => '',
					'visibility'    => array( 'map_for_page_builder' => false ),
				)
			);
		}

		public function render( $options, $content = null ) {
			parent::render( $options );
			$atts            = $this->get_atts();
			$atts['content'] = $content;

			return cuthbert_core_get_template_part( 'shortcodes/accordion', 'variations/' . $atts['layout'] . '/templates/child', '', $atts );
		}
	}
}
