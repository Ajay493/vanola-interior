<?php

if ( ! function_exists( 'cuthbert_core_add_accordion_variation_simple' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function cuthbert_core_add_accordion_variation_simple( $variations ) {
		$variations['simple'] = esc_html__( 'Simple', 'cuthbert-core' );

		return $variations;
	}

	add_filter( 'cuthbert_core_filter_accordion_layouts', 'cuthbert_core_add_accordion_variation_simple' );
}
