<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/helper.php';
include_once CUTHBERT_CORE_SHORTCODES_PATH . '/class-cuthbertcore-shortcodes.php';
