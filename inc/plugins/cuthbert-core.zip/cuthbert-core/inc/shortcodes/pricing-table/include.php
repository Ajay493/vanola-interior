<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/pricing-table/class-cuthbertcore-pricing-table-shortcode.php';

foreach ( glob( CUTHBERT_CORE_SHORTCODES_PATH . '/pricing-table/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
