<?php if ( ! empty( $title ) ) { ?>
	<div class="qodef-m-title">
		<p <?php qode_framework_inline_style( $title_styles ); ?>><?php echo esc_html( $title ); ?></p>
	</div>
<?php } ?>
