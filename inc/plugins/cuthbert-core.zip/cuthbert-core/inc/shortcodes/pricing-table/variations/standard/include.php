<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/pricing-table/variations/standard/helper.php';
