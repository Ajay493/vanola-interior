<?php

include_once CUTHBERT_CORE_SHORTCODES_PATH . '/icon-list-item/widget/class-cuthbertcore-icon-list-item-widget.php';
