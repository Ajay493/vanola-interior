<?php

if ( ! function_exists( 'cuthbert_core_filter_blog_list_metro_animation_options' ) ) {
	/**
	 * Function that add additional options for variation layout
	 *
	 * @param array $options
	 *
	 * @return array
	 */
	function cuthbert_core_filter_blog_list_metro_animation_options( $options ) {
		$hover_option  = array();
		$option_filter = apply_filters( 'cuthbert_core_filter_blog_list_metro_animation_options', array() );
		$options_map   = cuthbert_core_get_variations_options_map( $option_filter );

		$option = array(
			'field_type'    => 'select',
			'name'          => 'hover_animation_metro',
			'title'         => esc_html__( 'Hover Animation', 'cuthbert-core' ),
			'options'       => $option_filter,
			'default_value' => $options_map['default_value'],
			'dependency'    => array(
				'show' => array(
					'layout' => array(
						'values'        => 'metro',
						'default_value' => '',
					),
				),
			),
			'group'         => esc_html__( 'Layout', 'cuthbert-core' ),
			'visibility'    => array( 'map_for_page_builder' => $options_map['visibility'] ),
		);

		$hover_option[] = $option;

		return array_merge( $options, $hover_option );
	}

	add_filter( 'cuthbert_core_filter_blog_list_hover_animation_options', 'cuthbert_core_filter_blog_list_metro_animation_options' );
}
