<?php

if ( ! function_exists( 'cuthbert_core_add_blog_list_variation_simple' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function cuthbert_core_add_blog_list_variation_simple( $variations ) {
		$variations['simple'] = esc_html__( 'Simple', 'cuthbert-core' );

		return $variations;
	}

	add_filter( 'cuthbert_core_filter_blog_list_layouts', 'cuthbert_core_add_blog_list_variation_simple' );
	add_filter( 'cuthbert_core_filter_simple_blog_list_widget_layouts', 'cuthbert_core_add_blog_list_variation_simple' );
}
