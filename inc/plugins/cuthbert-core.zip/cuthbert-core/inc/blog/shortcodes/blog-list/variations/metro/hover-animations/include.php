<?php

include_once CUTHBERT_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/metro/hover-animations/hover-animations.php';

foreach ( glob( CUTHBERT_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/metro/hover-animations/*/include.php' ) as $animation ) {
	include_once $animation;
}
