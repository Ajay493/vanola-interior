(function ( $ ) {
	'use strict';

	$( document ).ready(
		function () {
			qodefExpand.init();
		}
	);

	$( window ).resize(
		function () {
			qodefExpand.init();
		}
	);

	$( document ).on(
		'cuthbert_trigger_get_new_posts',
		function ( e, $holder ) {
			if ( $holder.hasClass( 'qodef-hover-animation--expand' ) ) {
				qodefExpand.calc( $holder );
			}
		}
	);

	var qodefExpand = {
		init: function () {
			var $holder = $( '.qodef-hover-animation--expand' );

			if ( $holder.length ) {
				qodefExpand.calc( $holder );
			}
		},
		calc: function ( $holder ) {
			var $itemInner = $holder.find( '.qodef-e-inner' );

			if ( $itemInner.length ) {
				$itemInner.each(
					function () {
						var $thisItem = $( this ),
							$thisItemExcerpt  = $thisItem.find( '.qodef-e-excerpt' ),
							$excerptHeight = $thisItemExcerpt.outerHeight();

						$thisItem.css('--qodef-offset', $excerptHeight);
					}
				);
			}
		}
	};

	qodefCore.shortcodes.cuthbert_core_blog_list.qodefExpand = qodefExpand;

})( jQuery );
