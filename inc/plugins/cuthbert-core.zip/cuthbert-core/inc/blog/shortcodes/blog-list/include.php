<?php

include_once CUTHBERT_CORE_INC_PATH . '/blog/shortcodes/blog-list/class-cuthbertcore-blog-list-shortcode.php';

foreach ( glob( CUTHBERT_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
