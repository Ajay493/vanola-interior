<?php

include_once CUTHBERT_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-cuthbertcore-blog-list-widget.php';
include_once CUTHBERT_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-cuthbertcore-simple-blog-list-widget.php';
