<?php

if ( ! function_exists( 'cuthbert_core_add_blog_list_variation_metro' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function cuthbert_core_add_blog_list_variation_metro( $variations ) {
		$variations['metro'] = esc_html__( 'Metro', 'cuthbert-core' );

		return $variations;
	}

	add_filter( 'cuthbert_core_filter_blog_list_layouts', 'cuthbert_core_add_blog_list_variation_metro' );
}
