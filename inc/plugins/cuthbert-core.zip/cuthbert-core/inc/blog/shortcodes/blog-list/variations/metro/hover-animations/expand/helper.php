<?php

if ( ! function_exists( 'cuthbert_core_filter_blog_list_metro' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function cuthbert_core_filter_blog_list_metro( $variations ) {
		$variations['expand'] = esc_html__( 'Expand', 'cuthbert-core' );

		return $variations;
	}

	add_filter( 'cuthbert_core_filter_blog_list_metro_animation_options', 'cuthbert_core_filter_blog_list_metro' );
}
