<?php

if ( ! function_exists( 'cuthbert_core_add_social_share_variation_dropdown' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function cuthbert_core_add_social_share_variation_dropdown( $variations ) {
		$variations['dropdown'] = esc_html__( 'Dropdown', 'cuthbert-core' );

		return $variations;
	}

	add_filter( 'cuthbert_core_filter_social_share_layouts', 'cuthbert_core_add_social_share_variation_dropdown' );
	add_filter( 'cuthbert_core_filter_social_share_layout_options', 'cuthbert_core_add_social_share_variation_dropdown' );
}
