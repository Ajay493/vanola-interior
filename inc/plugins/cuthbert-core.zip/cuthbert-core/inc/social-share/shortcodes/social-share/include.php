<?php

include_once CUTHBERT_CORE_INC_PATH . '/social-share/shortcodes/social-share/class-cuthbertcore-social-share-shortcode.php';

foreach ( glob( CUTHBERT_CORE_INC_PATH . '/social-share/shortcodes/social-share/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
