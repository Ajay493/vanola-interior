<?php

if ( ! function_exists( 'cuthbert_core_add_social_share_variation_list' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function cuthbert_core_add_social_share_variation_list( $variations ) {
		$variations['list'] = esc_html__( 'List', 'cuthbert-core' );

		return $variations;
	}

	add_filter( 'cuthbert_core_filter_social_share_layouts', 'cuthbert_core_add_social_share_variation_list' );
	add_filter( 'cuthbert_core_filter_social_share_layout_options', 'cuthbert_core_add_social_share_variation_list' );
}
