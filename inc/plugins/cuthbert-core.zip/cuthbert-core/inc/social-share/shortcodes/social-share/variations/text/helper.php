<?php

if ( ! function_exists( 'cuthbert_core_add_social_share_variation_text' ) ) {
	/**
	 * Function that add variation layout for this module
	 *
	 * @param array $variations
	 *
	 * @return array
	 */
	function cuthbert_core_add_social_share_variation_text( $variations ) {
		$variations['text'] = esc_html__( 'Text', 'cuthbert-core' );

		return $variations;
	}

	add_filter( 'cuthbert_core_filter_social_share_layouts', 'cuthbert_core_add_social_share_variation_text' );
	add_filter( 'cuthbert_core_filter_social_share_layout_options', 'cuthbert_core_add_social_share_variation_text' );
}

if ( ! function_exists( 'cuthbert_core_set_default_social_share_variation_text' ) ) {
	/**
	 * Function that set default variation layout for this module
	 *
	 * @return string
	 */
	function cuthbert_core_set_default_social_share_variation_text() {
		return 'text';
	}

	add_filter( 'cuthbert_core_filter_social_share_layout_default_value', 'cuthbert_core_set_default_social_share_variation_text' );
}
