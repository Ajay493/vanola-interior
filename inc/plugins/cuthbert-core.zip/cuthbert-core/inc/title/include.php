<?php

include_once CUTHBERT_CORE_INC_PATH . '/title/helper.php';
include_once CUTHBERT_CORE_INC_PATH . '/title/class-cuthbertcore-title.php';
include_once CUTHBERT_CORE_INC_PATH . '/title/class-cuthbertcore-titles.php';
