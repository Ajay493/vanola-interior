<?php

include_once CUTHBERT_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/helper.php';
include_once CUTHBERT_CORE_INC_PATH . '/title/layouts/standard-with-breadcrumbs/class-cuthbertcore-standard-with-breadcrumbs-title.php';
