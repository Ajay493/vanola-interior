<?php if ( ! empty( $subtitle ) ) { ?>
	<p class="qodef-m-subtitle"><?php echo esc_html( $subtitle ); ?></p>
<?php } ?>
