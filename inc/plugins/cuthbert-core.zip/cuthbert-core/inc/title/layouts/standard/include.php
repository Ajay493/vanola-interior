<?php

include_once CUTHBERT_CORE_INC_PATH . '/title/layouts/standard/helper.php';
include_once CUTHBERT_CORE_INC_PATH . '/title/layouts/standard/class-cuthbertcore-standard-title.php';
include_once CUTHBERT_CORE_INC_PATH . '/title/layouts/standard/dashboard/meta-box/standard-title-meta-box.php';
