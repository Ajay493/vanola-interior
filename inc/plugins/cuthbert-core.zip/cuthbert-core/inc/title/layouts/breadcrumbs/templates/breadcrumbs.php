<?php
// Load title image template
cuthbert_core_get_page_title_image();
?>
<div class="qodef-m-content <?php echo esc_attr( cuthbert_core_get_page_title_content_classes() ); ?>">
	<?php
	// Load breadcrumbs template
	cuthbert_core_breadcrumbs();
	?>
</div>
