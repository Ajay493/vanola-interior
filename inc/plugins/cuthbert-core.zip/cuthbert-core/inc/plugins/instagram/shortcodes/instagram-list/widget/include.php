<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-cuthbertcore-instagram-list-widget.php';
