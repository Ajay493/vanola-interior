<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once CUTHBERT_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-cuthbertcore-instagram-list-shortcode.php';
