<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/wpbakery/helper.php';
