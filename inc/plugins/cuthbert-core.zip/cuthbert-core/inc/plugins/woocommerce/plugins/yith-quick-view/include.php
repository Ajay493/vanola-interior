<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-quick-view/dashboard/admin/woocommerce-yith-quick-view-options.php';
include_once CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-quick-view/helper.php';
include_once CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-quick-view/template-functions.php';
include_once CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/plugins/yith-quick-view/class-cuthbertcore-woocommerce-yith-quick-view.php';
