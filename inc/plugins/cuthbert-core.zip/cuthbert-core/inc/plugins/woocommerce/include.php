<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/class-cuthbertcore-woocommerce.php';
