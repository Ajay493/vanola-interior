<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/class-cuthbertcore-product-list-shortcode.php';

foreach ( glob( CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
