(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.cuthbert_core_product_category_list                    = {};
	qodefCore.shortcodes.cuthbert_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.cuthbert_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
