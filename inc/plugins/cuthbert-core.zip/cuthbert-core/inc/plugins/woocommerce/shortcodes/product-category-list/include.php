<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-category-list/media-custom-fields.php';
include_once CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-category-list/class-cuthbertcore-product-category-list-shortcode.php';

foreach ( glob( CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-category-list/variations/*/include.php' ) as $variation ) {
	include_once $variation;
}
