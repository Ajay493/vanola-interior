<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-cuthbertcore-woocommerce-dropdown-cart-widget.php';
