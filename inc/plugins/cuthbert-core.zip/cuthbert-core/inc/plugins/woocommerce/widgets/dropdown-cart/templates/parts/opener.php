<a itemprop="url" class="qodef-m-opener" href="<?php echo esc_url( wc_get_cart_url() ); ?>">
	<?php echo sprintf( '%s <span class="qodef-m-opener-text">%s</span>', cuthbert_get_svg_icon( 'cart' ), WC()->cart->cart_contents_count ); ?>
</a>
