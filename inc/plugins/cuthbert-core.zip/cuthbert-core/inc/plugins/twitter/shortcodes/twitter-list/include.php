<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-cuthbertcore-twitter-list-shortcode.php';
