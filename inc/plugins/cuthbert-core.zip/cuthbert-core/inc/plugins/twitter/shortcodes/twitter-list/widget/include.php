<?php

include_once CUTHBERT_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/widget/class-cuthbertcore-twitter-list-widget.php';
